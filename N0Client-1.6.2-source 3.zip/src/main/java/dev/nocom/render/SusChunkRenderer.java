package dev.nocom.render;

import dev.nocom.N0Client;
import dev.nocom.module.Modules;
import dev.nocom.suschunk.SusChunkScanner;
import dev.nocom.util.Colors;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

public final class SusChunkRenderer {
   private static final float FADE_IN_SECONDS  = 0.3F;
   private static final float FADE_OUT_SECONDS = 0.45F;
   private static final float MOVE_RATE = 7.0F;

   // Normal sus-chunk fades
   private static final Map<Long, ChunkFade> chunkFades = new HashMap();
   private static final Map<Long, ZoneFade> zoneFades   = new HashMap();

   // Portal-specific fades (separate so they can pulse white)
   private static final Map<Long, PortalFlashState> portalFades = new HashMap();

   private static long lastFrameNanos;

   // Flash cycle: 400 ms total, 150 ms bright
   private static final long FLASH_CYCLE_MS  = 400L;
   private static final long FLASH_ON_MS     = 150L;

   private SusChunkRenderer() {}

   public static void reset() {
      chunkFades.clear();
      zoneFades.clear();
      portalFades.clear();
   }

   public static String debugState() {
      StringBuilder sb = new StringBuilder();
      for (Map.Entry<Long, ChunkFade> entry : chunkFades.entrySet()) {
         ChunkFade fade = (ChunkFade) entry.getValue();
         sb.append(new ChunkPos((Long) entry.getKey()))
           .append("{a=").append(fade.alpha)
           .append(",t=").append(fade.tier)
           .append(",f=").append(fade.flagged).append("} ");
      }
      for (Map.Entry<Long, ZoneFade> entry : zoneFades.entrySet()) {
         ZoneFade zone = (ZoneFade) ((Map.Entry) entry).getValue();
         sb.append("zone").append(new ChunkPos((Long) entry.getKey()))
           .append("{a=").append(zone.alpha)
           .append(",s=").append(zone.size)
           .append(",f=").append(zone.flagged).append("} ");
      }
      return sb.toString();
   }

   public static void render(VertexConsumerProvider.Immediate bufferSource,
                             MatrixStack poseStack,
                             Vec3d camera,
                             Modules.SusChunkFinderModule module) {

      SusChunkScanner scanner = module.scanner;
      double y            = (Double) module.renderY.get();
      int    accent       = N0Client.themes().current().accent();
      float  fillAlpha    = module.fillOpacity.getFloat() / 255.0F;
      float  outlineAlpha = module.outlineOpacity.getFloat() / 255.0F;
      boolean outline     = (Boolean) module.outline.get();
      boolean smart       = (Boolean) module.smartMode.get();
      int    threshold    = scanner.threshold();

      updateTargets(scanner, smart, threshold);

      float dt   = frameDelta();
      float move = 1.0F - (float) Math.exp(-dt * MOVE_RATE);

      // ------------------------------------------------------------------
      // 1. Normal chunk / zone fades (amethyst + growth + spawner signal)
      // ------------------------------------------------------------------
      Iterator<Map.Entry<Long, ChunkFade>> chunks = chunkFades.entrySet().iterator();
      while (chunks.hasNext()) {
         Map.Entry<Long, ChunkFade> entry = (Map.Entry) chunks.next();
         ChunkFade fade = (ChunkFade) entry.getValue();
         fade.alpha += fade.flagged ? dt / FADE_IN_SECONDS : -dt / FADE_OUT_SECONDS;
         fade.alpha  = Math.clamp(fade.alpha, 0.0F, 1.0F);
         if (!fade.flagged && fade.alpha <= 0.0F) {
            chunks.remove();
         } else {
            double x0 = (double) ChunkPos.getPackedX((Long) entry.getKey()) * 16.0;
            double z0 = (double) ChunkPos.getPackedZ((Long) entry.getKey()) * 16.0;
            drawQuad(bufferSource, poseStack, camera,
                     x0, z0, x0 + 16.0, z0 + 16.0, y,
                     accent,
                     fillAlpha * fade.tier * fade.alpha,
                     outline ? outlineAlpha * fade.alpha : 0.0F);
         }
      }

      Iterator<Map.Entry<Long, ZoneFade>> zones = zoneFades.entrySet().iterator();
      while (zones.hasNext()) {
         ZoneFade zone = (ZoneFade) ((Map.Entry) zones.next()).getValue();
         zone.alpha += zone.flagged ? dt / FADE_IN_SECONDS : -dt / FADE_OUT_SECONDS;
         zone.alpha  = Math.clamp(zone.alpha, 0.0F, 1.0F);
         if (!zone.flagged && zone.alpha <= 0.0F) {
            zones.remove();
         } else {
            zone.centerX += (zone.targetX - zone.centerX) * (double) move;
            zone.centerZ += (zone.targetZ - zone.centerZ) * (double) move;
            zone.size    += (zone.targetSize - zone.size)  * move;
            double half = (double) zone.size / 2.0;
            drawQuad(bufferSource, poseStack, camera,
                     zone.centerX - half, zone.centerZ - half,
                     zone.centerX + half, zone.centerZ + half,
                     y, accent,
                     fillAlpha * zone.tier * zone.alpha,
                     outline ? outlineAlpha * zone.alpha : 0.0F);
            if ((Boolean) module.centroidMarker.get()) {
               FlatOverlay.marker(bufferSource, poseStack, camera,
                                  zone.centerX, zone.centerZ, y + 0.05,
                                  2.0, Colors.withAlpha(accent, 0.95F * zone.alpha));
            }
         }
      }

      // ------------------------------------------------------------------
      // 2. Portal flash overlay (white pulsing quads, separate layer)
      // ------------------------------------------------------------------
      if ((Boolean) module.portals.get()) {
         renderPortalFlash(bufferSource, poseStack, camera, scanner, y, dt);
      }

      FlatOverlay.flush(bufferSource);
   }

   // -----------------------------------------------------------------------
   // Portal flash — white pulse timed off System.currentTimeMillis()
   // -----------------------------------------------------------------------

   private static void renderPortalFlash(VertexConsumerProvider.Immediate bufferSource,
                                         MatrixStack poseStack,
                                         Vec3d camera,
                                         SusChunkScanner scanner,
                                         double y,
                                         float dt) {

      Set<Long> pChunks = scanner.portalChunks();
      if (pChunks.isEmpty()) {
         portalFades.clear();
         return;
      }

      // Compute flash alpha from the scanner's flash start time
      long startTime = scanner.portalFlashStartTime();
      float flashAlpha = 0.0F;
      if (startTime != 0L) {
         long elapsed = (System.currentTimeMillis() - startTime) % FLASH_CYCLE_MS;
         if (elapsed < FLASH_ON_MS) {
            float progress = (float) elapsed / (float) FLASH_ON_MS;
            // Ease-in: bright at start, fades out by end of on-window
            flashAlpha = (1.0F - progress) * (200.0F / 255.0F);
         }
      }

      // Fade-in / fade-out per portal chunk
      for (Long key : pChunks) {
         PortalFlashState state = portalFades.computeIfAbsent(key, k -> new PortalFlashState());
         state.alpha  = Math.min(1.0F, state.alpha + dt / FADE_IN_SECONDS);
         state.active = true;
      }
      Iterator<Map.Entry<Long, PortalFlashState>> pit = portalFades.entrySet().iterator();
      while (pit.hasNext()) {
         Map.Entry<Long, PortalFlashState> entry = (Map.Entry) pit.next();
         PortalFlashState state = (PortalFlashState) entry.getValue();
         if (!state.active) {
            state.alpha -= dt / FADE_OUT_SECONDS;
            if (state.alpha <= 0.0F) { pit.remove(); continue; }
         }
         state.active = false; // will be re-set next frame if still in portalChunks

         double x0 = (double) ChunkPos.getPackedX((Long) entry.getKey()) * 16.0;
         double z0 = (double) ChunkPos.getPackedZ((Long) entry.getKey()) * 16.0;
         float  fa = flashAlpha * state.alpha;
         // White fill + slightly raised Y to sit above the sus-chunk quad
         int whiteColor = Colors.withAlpha(0xFFFFFF, fa * 0.78F);
         FlatOverlay.fillQuad(bufferSource, poseStack, camera,
                              x0, z0, x0 + 16.0, z0 + 16.0,
                              y + 0.15, whiteColor);
         // Bright white border
         int borderColor = Colors.withAlpha(0xFFFFFF, fa);
         FlatOverlay.edge(bufferSource, poseStack, camera, x0,       z0,       x0 + 16, z0,        y + 0.15, borderColor, 3.0F);
         FlatOverlay.edge(bufferSource, poseStack, camera, x0,       z0 + 16,  x0 + 16, z0 + 16,   y + 0.15, borderColor, 3.0F);
         FlatOverlay.edge(bufferSource, poseStack, camera, x0,       z0,       x0,       z0 + 16,   y + 0.15, borderColor, 3.0F);
         FlatOverlay.edge(bufferSource, poseStack, camera, x0 + 16,  z0,       x0 + 16,  z0 + 16,  y + 0.15, borderColor, 3.0F);
      }
   }

   // -----------------------------------------------------------------------
   // Quad helper
   // -----------------------------------------------------------------------

   private static void drawQuad(VertexConsumerProvider.Immediate bufferSource,
                                 MatrixStack poseStack,
                                 Vec3d camera,
                                 double x0, double z0, double x1, double z1,
                                 double y, int accent, float fill, float border) {
      FlatOverlay.fillQuad(bufferSource, poseStack, camera, x0, z0, x1, z1, y, Colors.withAlpha(accent, fill));
      if (border > 0.004F) {
         int color = Colors.withAlpha(accent, border);
         FlatOverlay.edge(bufferSource, poseStack, camera, x0, z0, x1, z0, y, color, 2.5F);
         FlatOverlay.edge(bufferSource, poseStack, camera, x0, z1, x1, z1, y, color, 2.5F);
         FlatOverlay.edge(bufferSource, poseStack, camera, x0, z0, x0, z1, y, color, 2.5F);
         FlatOverlay.edge(bufferSource, poseStack, camera, x1, z0, x1, z1, y, color, 2.5F);
      }
   }

   // -----------------------------------------------------------------------
   // Update targets from scanner
   // -----------------------------------------------------------------------

   private static void updateTargets(SusChunkScanner scanner, boolean smart, int threshold) {
      for (ChunkFade fade : chunkFades.values())  fade.flagged = false;
      for (ZoneFade  zone : zoneFades.values())   zone.flagged = false;

      if (smart) {
         for (SusChunkScanner.Zone zone : scanner.zones()) {
            if (zone.members().size() == 1) {
               long key = (Long) zone.members().iterator().next();
               ChunkFade fade = (ChunkFade) chunkFades.computeIfAbsent(key, (k) -> new ChunkFade());
               fade.flagged = true;
               fade.tier    = confidence(zone.maxScore(), threshold);
            } else {
               long key = Long.MAX_VALUE;
               for (long member : zone.members()) key = Math.min(key, member);

               ZoneFade fade = (ZoneFade) zoneFades.get(key);
               if (fade == null) {
                  fade = new ZoneFade(zone.centroidX(), zone.centroidZ());
                  zoneFades.put(key, fade);
               }
               fade.flagged    = true;
               fade.targetX    = zone.centroidX();
               fade.targetZ    = zone.centroidZ();
               fade.targetSize = Math.min(48.0F, 16.0F + (float) (zone.members().size() - 1) * 8.0F);
               fade.tier       = confidence(zone.maxScore(), threshold);
            }
         }
      } else {
         for (SusChunkScanner.Flag flag : scanner.flags()) {
            ChunkFade fade = (ChunkFade) chunkFades.computeIfAbsent(flag.chunkKey(), (k) -> new ChunkFade());
            fade.flagged = true;
            fade.tier    = 1.0F;
         }
      }
   }

   private static float confidence(double score, int threshold) {
      if (threshold <= 0) return 1.0F;
      float over = (float) ((score - (double) threshold) / ((double) threshold * 2.0));
      return 0.55F + 0.45F * Math.clamp(over, 0.0F, 1.0F);
   }

   private static float frameDelta() {
      long now = System.nanoTime();
      float dt = lastFrameNanos == 0L ? 0.016F : (float) (now - lastFrameNanos) / 1.0E9F;
      lastFrameNanos = now;
      return Math.min(dt, 0.1F);
   }

   // -----------------------------------------------------------------------
   // Internal state types
   // -----------------------------------------------------------------------

   private static final class ChunkFade {
      float   alpha;
      float   tier   = 1.0F;
      boolean flagged;
   }

   private static final class ZoneFade {
      double  centerX, centerZ;
      double  targetX, targetZ;
      float   size       = 16.0F;
      float   targetSize = 16.0F;
      float   alpha;
      float   tier       = 1.0F;
      boolean flagged;

      ZoneFade(double x, double z) {
         this.centerX = this.targetX = x;
         this.centerZ = this.targetZ = z;
      }
   }

   private static final class PortalFlashState {
      float   alpha;
      boolean active;
   }
}
