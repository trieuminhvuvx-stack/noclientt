package dev.nocom.render;

import dev.nocom.render.nanovg.NVGRenderer;

public interface NvgDrawable {
   void renderNvg(NVGRenderer var1, float var2, float var3, float var4, float var5);
}
