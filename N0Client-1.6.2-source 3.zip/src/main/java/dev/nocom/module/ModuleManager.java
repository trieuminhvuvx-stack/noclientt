package dev.nocom.module;

import dev.nocom.module.impl.AimAssistModule;
import dev.nocom.module.impl.AnchorMacroModule;
import dev.nocom.module.impl.ArmorTrimHiderModule;
import dev.nocom.module.impl.AutoClickerModule;
import dev.nocom.module.impl.AutoCrystalModule;
import dev.nocom.module.impl.AutoInventoryTotemModule;
import dev.nocom.module.impl.AutoTotemModule;
import dev.nocom.module.impl.AutoTpaModule;
import dev.nocom.module.impl.AutoWalkModule;
import dev.nocom.module.impl.BlockEntityEspModule;
import dev.nocom.module.impl.BlockEspModule;
import dev.nocom.module.impl.ChatMacroModule;
import dev.nocom.module.impl.ChunkFinderModule;
import dev.nocom.module.impl.CoordSnapperModule;
import dev.nocom.module.impl.CustomAccessoriesModule;
import dev.nocom.module.impl.CustomCrosshairModule;
import dev.nocom.module.impl.CustomFovModule;
import dev.nocom.module.impl.CustomGlintModule;
import dev.nocom.module.impl.DebugHoleEspModule;
import dev.nocom.module.impl.DoubleAnchorModule;
import dev.nocom.module.impl.ElytraSwapModule;
import dev.nocom.module.impl.FakePayModule;
import dev.nocom.module.impl.FakeRolesModule;
import dev.nocom.module.impl.FakeStatsModule;
import dev.nocom.module.impl.FastUseModule;
import dev.nocom.module.impl.FreeLookModule;
import dev.nocom.module.impl.FreecamModule;
import dev.nocom.module.impl.FullbrightModule;
import dev.nocom.module.impl.GambleRiggerModule;
import dev.nocom.module.impl.HitBoxModule;
import dev.nocom.module.impl.HitParticlesModule;
import dev.nocom.module.impl.HoverTotemModule;
import dev.nocom.module.impl.JumpCirclesModule;
import dev.nocom.module.impl.MaceBomberModule;
import dev.nocom.module.impl.MaceSwapModule;
import dev.nocom.module.impl.MobEspModule;
import dev.nocom.module.impl.MotionBlurModule;
import dev.nocom.module.impl.NameProtectModule;
import dev.nocom.module.impl.NameTagsModule;
import dev.nocom.module.impl.PlayerEspModule;
import dev.nocom.module.impl.RegionMapModule;
import dev.nocom.module.impl.ShieldBreakerModule;
import dev.nocom.module.impl.SkinProtectModule;
import dev.nocom.module.impl.SpawnerNametagsModule;
import dev.nocom.module.impl.SpawnerProtectModule;
import dev.nocom.module.impl.StaffListModule;
import dev.nocom.module.impl.StorageEspModule;
import dev.nocom.module.impl.SwingSpeedModule;
import dev.nocom.module.impl.TriggerbotModule;
import dev.nocom.module.impl.WeatherNotifierModule;
import dev.nocom.module.impl.ZoomModule;
import dev.nocom.settings.BooleanSetting;
import dev.nocom.settings.ModeSetting;
import dev.nocom.settings.Setting;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

public class ModuleManager {
   private final List<Module> modules = new ArrayList();
   private final Map<Category, List<Module>> byCategory = new LinkedHashMap();
   public final Modules.ClickGuiModule clickGui;
   public final Modules.HudModule hud;
   public final Modules.SpotifyModule spotify;
   public final Modules.BlockOutlineModule blockOutline;
   public final Modules.SusChunkFinderModule susChunkFinder;
   public FullbrightModule fullbright;
   public AutoWalkModule autoWalk;
   public WeatherNotifierModule weatherNotifier;
   public SwingSpeedModule swingSpeed;
   public StorageEspModule storageEsp;
   public BlockEspModule blockEsp;
   public AutoTotemModule autoTotem;
   public MaceSwapModule maceSwap;
   public AnchorMacroModule anchorMacro;
   public AutoCrystalModule autoCrystal;
   public HitBoxModule hitBox;
   public ElytraSwapModule elytraSwap;
   public HoverTotemModule hoverTotem;
   public ShieldBreakerModule shieldBreaker;
   public TriggerbotModule triggerbot;
   public AimAssistModule aimAssist;
   public DoubleAnchorModule doubleAnchor;
   public MaceBomberModule maceBomber;
   public NameProtectModule nameProtect;
   public SkinProtectModule skinProtect;
   public NameTagsModule nameTags;
   public FastUseModule fastUse;
   public AutoInventoryTotemModule autoInventoryTotem;
   public PlayerEspModule playerEsp;
   public MobEspModule mobEsp;
   public BlockEntityEspModule blockEntityEsp;
   public SpawnerNametagsModule spawnerNametags;
   public DebugHoleEspModule debugHoleEsp;
   public FreecamModule freecam;
   public AutoTpaModule autoTpa;
   public JumpCirclesModule jumpCircles;
   public CustomCrosshairModule customCrosshair;
   public ZoomModule zoom;
   public CustomFovModule customFov;
   public HitParticlesModule hitParticles;
   public MotionBlurModule motionBlur;
   public CustomGlintModule customGlint;
   public CustomAccessoriesModule customAccessories;
   public ChunkFinderModule chunkFinder;
   public FreeLookModule freeLook;
   public AutoClickerModule autoClicker;
   public CoordSnapperModule coordSnapper;
   public RegionMapModule regionMap;
   public ChatMacroModule chatMacro;
   public FakePayModule fakePay;
   public FakeStatsModule fakeStats;
   public FakeRolesModule fakeRoles;
   public StaffListModule staffList;
   public ArmorTrimHiderModule armorTrimHider;
   public SpawnerProtectModule spawnerProtect;
   public GambleRiggerModule gambleRigger;
   private Runnable openGuiAction = () -> {
   };
   private BiConsumer<Module, Boolean> toggleListener = (m, e) -> {
   };

   public ModuleManager() {
      for(Category category : Category.values()) {
         this.byCategory.put(category, new ArrayList());
      }

      this.susChunkFinder = new Modules.SusChunkFinderModule();
      this.registerPlaceholders();
      this.register(this.blockOutline = new Modules.BlockOutlineModule());
      this.register(this.hitParticles = new HitParticlesModule());
      this.register(this.customAccessories = new CustomAccessoriesModule());
      this.register(this.motionBlur = new MotionBlurModule());
      this.register(this.hud = new Modules.HudModule());
      this.register(this.spotify = new Modules.SpotifyModule());
      this.register(this.chatMacro = new ChatMacroModule());
      this.ph("ConfigShare", "Import/export configs via codes", Category.CLIENT, new BooleanSetting("Include HUD Layout", "Share HUD positions too", true));
      this.register(this.swingSpeed = new SwingSpeedModule());
      this.register(this.jumpCircles = new JumpCirclesModule());
      this.register(this.clickGui = new Modules.ClickGuiModule());
   }

   private void registerPlaceholders() {
      this.register(this.autoTotem = new AutoTotemModule());
      this.register(this.autoCrystal = new AutoCrystalModule());
      this.register(this.anchorMacro = new AnchorMacroModule());
      this.register(this.doubleAnchor = new DoubleAnchorModule());
      this.register(this.autoInventoryTotem = new AutoInventoryTotemModule());
      this.register(this.aimAssist = new AimAssistModule());
      this.register(this.maceSwap = new MaceSwapModule());
      this.register(this.hitBox = new HitBoxModule());
      this.register(this.elytraSwap = new ElytraSwapModule());
      this.register(this.hoverTotem = new HoverTotemModule());
      this.register(this.shieldBreaker = new ShieldBreakerModule());
      this.register(this.triggerbot = new TriggerbotModule());
      this.register(this.maceBomber = new MaceBomberModule());
      this.register(this.skinProtect = new SkinProtectModule());
      this.register(this.nameProtect = new NameProtectModule());
      this.register(this.freecam = new FreecamModule());
      this.register(this.autoTpa = new AutoTpaModule());
      this.register(this.autoClicker = new AutoClickerModule());
      this.register(this.fastUse = new FastUseModule());
      this.register(this.nameTags = new NameTagsModule());
      this.register(this.fakePay = new FakePayModule());
      this.register(this.weatherNotifier = new WeatherNotifierModule());
      this.register(this.fakeStats = new FakeStatsModule());
      this.register(this.fakeRoles = new FakeRolesModule());
      this.register(this.armorTrimHider = new ArmorTrimHiderModule());
      this.register(this.customCrosshair = new CustomCrosshairModule());
      this.ph("Media/StaffNames/Icons", "Marks media & staff players with icons", Category.MISC, new BooleanSetting("Media", "Show media icons", true), new BooleanSetting("Staff", "Show staff icons", true), new ModeSetting("Position", "Icon position", "Prefix", new String[]{"Prefix", "Suffix"}));
      this.register(this.staffList = new StaffListModule());
      this.register(this.customGlint = new CustomGlintModule());
      this.register(this.customFov = new CustomFovModule());
      this.register(this.coordSnapper = new CoordSnapperModule());
      this.register(this.autoWalk = new AutoWalkModule());
      this.register(this.zoom = new ZoomModule());
      this.register(this.freeLook = new FreeLookModule());
      this.register(this.spawnerProtect = new SpawnerProtectModule());
      this.register(this.gambleRigger = new GambleRiggerModule());
      this.register(this.blockEsp = new BlockEspModule());
      this.register(this.storageEsp = new StorageEspModule());
      this.register(this.blockEntityEsp = new BlockEntityEspModule());
      this.register(this.debugHoleEsp = new DebugHoleEspModule());
      this.register(this.fullbright = new FullbrightModule());
      this.register(this.playerEsp = new PlayerEspModule());
      this.register(this.mobEsp = new MobEspModule());
      this.register(this.spawnerNametags = new SpawnerNametagsModule());
      this.register(this.susChunkFinder);
      this.register(this.chunkFinder = new ChunkFinderModule());
      this.register(this.regionMap = new RegionMapModule());
   }

   private void ph(String name, String description, Category category, Setting<?>... settings) {
      this.register(new Modules.Placeholder(name, description, category, settings));
   }

   public void register(Module module) {
      this.modules.add(module);
      ((List)this.byCategory.get(module.getCategory())).add(module);
      module.setToggleCallback(this::notifyToggle);
   }

   public List<Module> all() {
      return this.modules;
   }

   public List<Module> inCategory(Category category) {
      return (List)this.byCategory.get(category);
   }

   public void setOpenGuiAction(Runnable action) {
      this.openGuiAction = action;
   }

   public void setToggleListener(BiConsumer<Module, Boolean> listener) {
      this.toggleListener = listener;
   }

   public void notifyToggle(Module module, boolean enabled) {
      this.toggleListener.accept(module, enabled);
   }

   public boolean onKeyPressed(int keyCode) {
      if (this.clickGui.getKeybind().matches(keyCode)) {
         this.openGuiAction.run();
         return true;
      } else {
         boolean handled = false;

         for(Module module : this.modules) {
            if (module != this.clickGui && module.getKeybind().matches(keyCode)) {
               module.toggle();
               handled = true;
            }
         }

         for(Module module : this.modules) {
            if (module.isEnabled() && module.onKeyPress(keyCode)) {
               handled = true;
            }
         }

         return handled;
      }
   }

   public void onTick() {
      for(Module module : this.modules) {
         if (module.isEnabled() && module.getCategory() != Category.COMBAT) {
            module.onTick();
         }
      }

   }

   public void onCombatTick() {
      for(Module module : this.modules) {
         if (module.isEnabled() && module.getCategory() == Category.COMBAT) {
            module.onTick();
         }
      }

   }
}
