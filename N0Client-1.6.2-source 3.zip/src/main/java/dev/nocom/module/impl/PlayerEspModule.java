package dev.nocom.module.impl;

import dev.nocom.module.Category;
import dev.nocom.module.Module;
import dev.nocom.settings.BooleanSetting;
import dev.nocom.settings.ColorSetting;
import dev.nocom.settings.ModeSetting;

public class PlayerEspModule extends Module {
   public final ModeSetting style = (ModeSetting)this.addSetting(new ModeSetting("Style", "Highlight style", "Outline", new String[]{"Box", "Outline", "Glow"}));
   public final ColorSetting color = (ColorSetting)this.addSetting(new ColorSetting("Color", "Highlight color", -49508));
   public final BooleanSetting tracers = (BooleanSetting)this.addSetting(new BooleanSetting("Tracers", "Draw lines from the crosshair to each player", false));

   public PlayerEspModule() {
      super("PlayerESP", "Highlights players through walls", Category.RENDER);
   }
}
