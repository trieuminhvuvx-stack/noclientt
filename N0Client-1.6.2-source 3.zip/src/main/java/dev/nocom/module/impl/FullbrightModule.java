package dev.nocom.module.impl;

import dev.nocom.module.Category;
import dev.nocom.module.Module;
import dev.nocom.settings.SliderSetting;

public class FullbrightModule extends Module {
   public final SliderSetting gamma = (SliderSetting)this.addSetting(new SliderSetting("Gamma", "Brightness boost", (double)12.0F, (double)1.0F, (double)15.0F, (double)1.0F));

   public FullbrightModule() {
      super("FullBright", "Maximum brightness everywhere", Category.RENDER);
   }
}
