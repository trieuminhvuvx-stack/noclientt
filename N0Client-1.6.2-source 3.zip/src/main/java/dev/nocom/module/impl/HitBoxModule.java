package dev.nocom.module.impl;

import dev.nocom.module.Category;
import dev.nocom.module.Module;
import dev.nocom.settings.BooleanSetting;
import dev.nocom.settings.SliderSetting;

public class HitBoxModule extends Module {
   public final SliderSetting expand = (SliderSetting)this.addSetting(new SliderSetting("Expand", "Disabled vs prediction anticheats \u2014 kept for config compatibility", (double)0.5F, (double)0.0F, (double)2.0F, 0.05));
   public final BooleanSetting enableRender = (BooleanSetting)this.addSetting(new BooleanSetting("Enable Render", "", true));

   public HitBoxModule() {
      super("HitBox", "Hitbox expander (neutered: undetectable = does not widen server hitboxes)", Category.COMBAT);
   }

   public float getHitboxExpansion() {
      return this.isEnabled() ? this.expand.getFloat() : 0.0F;
   }

   public boolean shouldRender() {
      return this.isEnabled() && (Boolean)this.enableRender.get();
   }
}
