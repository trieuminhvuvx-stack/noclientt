package dev.nocom.suschunk;

import dev.nocom.N0Client;
import dev.nocom.module.Modules;
import dev.nocom.util.UiSounds;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public class SusChunkScanner {
   public static final int POINTS_PER_SENSITIVITY = 5;
   private static final int GEODE_LINK_DISTANCE = 5;
   // Portal detection: minimum portal blocks to flag a chunk as containing a portal
   private static final int PORTAL_BLOCK_THRESHOLD = 10;
   private static final boolean DEBUG_LOG = Boolean.getBoolean("n0client.sus.debug");

   private final Modules.SusChunkFinderModule module;
   private final Map<Long, ChunkScore> scores = new ConcurrentHashMap();
   private final Deque<Long> queue = new ArrayDeque();
   private final Set<Long> lightRescans = ConcurrentHashMap.newKeySet();
   private final Set<Long> alertedChunks = new HashSet();
   // Portal chunks tracked separately for flash rendering — concurrent for renderer thread safety
   private volatile Set<Long> portalChunks = Collections.emptySet();
   private volatile long portalFlashStartTime = 0L;
   private volatile List<Flag> flags = List.of();
   private volatile List<Zone> zones = List.of();
   private ChunkPos lastQueueCenter;
   private int tickCounter;

   public SusChunkScanner(Modules.SusChunkFinderModule module) {
      this.module = module;
      ServerLightCache var10000 = ServerLightCache.get();
      Set var10001 = this.lightRescans;
      Objects.requireNonNull(var10001);
      var10000.addDirtyListener(var10001::add);
   }

   public List<Flag> flags() {
      return this.flags;
   }

   public List<Zone> zones() {
      return this.zones;
   }

   /** Returns the current set of chunks known to contain portal blocks. */
   public Set<Long> portalChunks() {
      return this.portalChunks;
   }

   public long portalFlashStartTime() {
      return this.portalFlashStartTime;
   }

   public int threshold() {
      return this.module.sensitivity.getInt() * 5;
   }

   public void clear() {
      this.scores.clear();
      this.queue.clear();
      this.lightRescans.clear();
      this.alertedChunks.clear();
      this.flags = List.of();
      this.zones = List.of();
      this.portalChunks = Collections.emptySet();
      this.portalFlashStartTime = 0L;
      this.lastQueueCenter = null;
   }

   public void tick() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc.world != null && mc.player != null) {
         try {
            this.refillQueueIfNeeded(mc);
            int budget = this.module.scanSpeed.getInt();
            long deadline = System.nanoTime() + 2000000L;
            int scanned = this.scanLightRescans(mc, budget, deadline);
            this.scanQueue(mc, budget - scanned, deadline);
            if (++this.tickCounter % 10 == 0) {
               this.rebuild(mc);
            }
         } catch (Exception e) {
            N0Client.LOGGER.warn("SusChunkFinder scan error: {}", e.toString());
         }
      }
   }

   private int scanLightRescans(MinecraftClient mc, int budget, long deadline) {
      if (this.lightRescans.isEmpty()) {
         return 0;
      } else {
         int scanned = 0;
         Iterator<Long> iterator = this.lightRescans.iterator();
         while (iterator.hasNext() && scanned < budget && System.nanoTime() < deadline) {
            long key = (Long) iterator.next();
            iterator.remove();
            WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key), false);
            if (chunk != null && this.scores.containsKey(key)) {
               this.scores.put(key, this.scanChunk(mc, chunk));
               ++scanned;
            }
         }
         return scanned;
      }
   }

   private void scanQueue(MinecraftClient mc, int budget, long deadline) {
      int scanned = 0;
      int polled = 0;
      while (scanned < budget && polled < 128 && !this.queue.isEmpty() && System.nanoTime() < deadline) {
         ++polled;
         long key = (Long) this.queue.pollFirst();
         if (!this.scores.containsKey(key)) {
            WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key), false);
            if (chunk != null) {
               this.scores.put(key, this.scanChunk(mc, chunk));
               ++scanned;
            }
         }
      }
   }

   private void refillQueueIfNeeded(MinecraftClient mc) {
      ChunkPos center = mc.player.getChunkPos();
      if (this.queue.isEmpty() || this.lastQueueCenter == null
            || Math.max(Math.abs(center.x - this.lastQueueCenter.x), Math.abs(center.z - this.lastQueueCenter.z)) >= 3) {
         this.lastQueueCenter = center;
         this.queue.clear();
         int radius = Math.min((Integer) mc.options.getViewDistance().getValue() + 1, 16);
         List<Long> order = new ArrayList();
         for (int dx = -radius; dx <= radius; ++dx) {
            for (int dz = -radius; dz <= radius; ++dz) {
               long key = ChunkPos.toLong(center.x + dx, center.z + dz);
               if (!this.scores.containsKey(key)) {
                  order.add(key);
               }
            }
         }
         order.sort(Comparator.comparingDouble(
               (k) -> Math.hypot((double) (ChunkPos.getPackedX(k) - center.x), (double) (ChunkPos.getPackedZ(k) - center.z))));
         this.queue.addAll(order);
      }
   }

   // -------------------------------------------------------------------------
   // Block classifiers
   // -------------------------------------------------------------------------

   private static boolean isPlantTarget(BlockState state) {
      Block block = state.getBlock();
      return block == Blocks.KELP || block == Blocks.KELP_PLANT
            || block == Blocks.BAMBOO || block == Blocks.SWEET_BERRY_BUSH
            || block == Blocks.VINE || block == Blocks.POINTED_DRIPSTONE;
   }

   private static boolean isAmethystStructure(BlockState state) {
      return state.isOf(Blocks.BUDDING_AMETHYST) || state.isOf(Blocks.AMETHYST_BLOCK);
   }

   private static boolean isSpawnerOrVault(BlockState state) {
      return state.isOf(Blocks.SPAWNER) || state.isOf(Blocks.VAULT);
   }

   private static boolean isPortalBlock(BlockState state) {
      return state.isOf(Blocks.NETHER_PORTAL) || state.isOf(Blocks.END_PORTAL);
   }

   // -------------------------------------------------------------------------
   // Chunk scan — runs on client thread, budget-limited
   // -------------------------------------------------------------------------

   private ChunkScore scanChunk(MinecraftClient mc, WorldChunk chunk) {
      ChunkScore result = new ChunkScore(chunk.getPos().toLong());
      if ((Boolean) this.module.amethyst.get()) {
         this.detectAmethyst(mc, chunk, result);
      }
      this.detectGrowth(mc, chunk, result);
      if ((Boolean) this.module.spawners.get()) {
         this.detectSpawnersAndVaults(chunk, result);
      }
      if ((Boolean) this.module.portals.get()) {
         this.detectPortalBlocks(chunk, result);
      }
      result.computeScore();
      if (DEBUG_LOG && result.score > 0.0) {
         N0Client.LOGGER.info("[sus] chunk {} score={} hits={}", chunk.getPos(), result.score, result.hits);
      }
      return result;
   }

   // -------------------------------------------------------------------------
   // Amethyst light-5 detection (original logic)
   // -------------------------------------------------------------------------

   private void detectAmethyst(MinecraftClient mc, WorldChunk chunk, ChunkScore result) {
      List<BlockPos> cells = ServerLightCache.get().light5Positions(chunk.getPos().x, chunk.getPos().z);
      if (!cells.isEmpty()) {
         BlockPos.Mutable cursor = new BlockPos.Mutable();
         for (BlockPos cell : cells) {
            BlockState state = mc.world.getBlockState(cell);
            if ((state.isAir() || state.isOf(Blocks.AMETHYST_CLUSTER)) && hasAmethystNeighbour(mc, cell, cursor)) {
               result.amethystCells.add(cell.toImmutable());
               if (DEBUG_LOG) {
                  N0Client.LOGGER.info("[sus] AMETHYST light-5 cell @{} ({})", cell, state.isAir() ? "hidden" : "visible");
               }
            }
         }
      }
   }

   private static boolean hasAmethystNeighbour(MinecraftClient mc, BlockPos cell, BlockPos.Mutable cursor) {
      for (int dx = -1; dx <= 1; ++dx) {
         for (int dy = -1; dy <= 1; ++dy) {
            for (int dz = -1; dz <= 1; ++dz) {
               if (dx != 0 || dy != 0 || dz != 0) {
                  cursor.set(cell.getX() + dx, cell.getY() + dy, cell.getZ() + dz);
                  if (isAmethystStructure(mc.world.getBlockState(cursor))) {
                     return true;
                  }
               }
            }
         }
      }
      return false;
   }

   // -------------------------------------------------------------------------
   // Growth detection (original logic)
   // -------------------------------------------------------------------------

   private void detectGrowth(MinecraftClient mc, WorldChunk chunk, ChunkScore result) {
      ChunkSection[] sections = chunk.getSectionArray();
      int minSectionY = chunk.getBottomSectionCoord();
      int loSection = ChunkSectionPos.getSectionCoord(-12);
      int hiSection = ChunkSectionPos.getSectionCoord(80);
      int baseX = chunk.getPos().getStartX();
      int baseZ = chunk.getPos().getStartZ();
      BlockPos.Mutable cursor = new BlockPos.Mutable();

      for (int s = 0; s < sections.length; ++s) {
         int sectionY = minSectionY + s;
         if (sectionY >= loSection && sectionY <= hiSection) {
            ChunkSection section = sections[s];
            if (!section.isEmpty() && section.getBlockStateContainer().hasAny(SusChunkScanner::isPlantTarget)) {
               int baseY = sectionY << 4;
               for (int y = 0; y < 16; ++y) {
                  int worldY = baseY + y;
                  if (worldY >= -12 && worldY <= 80) {
                     for (int z = 0; z < 16; ++z) {
                        for (int x = 0; x < 16; ++x) {
                           BlockState state = section.getBlockState(x, y, z);
                           if (isPlantTarget(state)) {
                              cursor.set(baseX + x, worldY, baseZ + z);
                              this.inspectPlant(mc, state, cursor, result);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void inspectPlant(MinecraftClient mc, BlockState state, BlockPos pos, ChunkScore result) {
      Block block = state.getBlock();
      if ((block == Blocks.KELP || block == Blocks.KELP_PLANT) && (Boolean) this.module.kelp.get()) {
         BlockState above = mc.world.getBlockState(pos.up());
         if (above.isOf(Blocks.KELP) || above.isOf(Blocks.KELP_PLANT)) return;
         int height = columnLength(mc, pos, Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT);
         boolean maxAge = block == Blocks.KELP && state.contains(Properties.AGE_25) && (Integer) state.get(Properties.AGE_25) == 25;
         if (maxAge && height >= 8 || height >= 14) {
            result.add(SignalType.KELP, pos);
            if (DEBUG_LOG) N0Client.LOGGER.info("[sus] KELP @{} height={} maxAge={}", pos, height, maxAge);
         }
      } else if (block == Blocks.BAMBOO && (Boolean) this.module.bamboo.get()) {
         if (mc.world.getBlockState(pos.down()).isOf(Blocks.BAMBOO)) return;
         int height = columnLength(mc, pos, Direction.UP, Blocks.BAMBOO);
         if (height >= 12) {
            result.add(SignalType.BAMBOO, pos);
            if (DEBUG_LOG) N0Client.LOGGER.info("[sus] BAMBOO @{} height={}", pos, height);
         }
      } else if (block == Blocks.SWEET_BERRY_BUSH && (Boolean) this.module.berries.get()) {
         if (state.contains(Properties.AGE_3) && (Integer) state.get(Properties.AGE_3) == 3) {
            result.add(SignalType.BERRIES, pos);
            if (DEBUG_LOG) N0Client.LOGGER.info("[sus] BERRIES max age @{}", pos);
         }
      } else if (block == Blocks.VINE && (Boolean) this.module.vines.get()) {
         if (mc.world.getBlockState(pos.up()).isOf(Blocks.VINE)) return;
         int length = columnLength(mc, pos, Direction.DOWN, Blocks.VINE);
         if (length >= 7) {
            result.add(SignalType.VINES, pos);
            if (DEBUG_LOG) N0Client.LOGGER.info("[sus] VINES @{} hang={}", pos, length);
         }
      } else if (block == Blocks.POINTED_DRIPSTONE && (Boolean) this.module.dripstone.get()) {
         if (mc.world.getBlockState(pos.up()).isOf(Blocks.POINTED_DRIPSTONE)
               || !mc.world.getBlockState(pos.down()).isOf(Blocks.POINTED_DRIPSTONE)) return;
         int length = columnLength(mc, pos, Direction.DOWN, Blocks.POINTED_DRIPSTONE);
         if (length >= 5) {
            result.add(SignalType.DRIPSTONE, pos);
            if (DEBUG_LOG) N0Client.LOGGER.info("[sus] DRIPSTONE @{} length={}", pos, length);
         }
      }
   }

   private static int columnLength(MinecraftClient mc, BlockPos start, Direction dir, Block... blocks) {
      int length = 1;
      label22:
      for (BlockPos.Mutable cursor = start.mutableCopy(); length < 40; ++length) {
         cursor.move(dir);
         BlockState state = mc.world.getBlockState(cursor);
         for (Block block : blocks) {
            if (state.isOf(block)) { ; }
         }
         break;
      }
      return length;
   }

   // -------------------------------------------------------------------------
   // Spawner / Vault detection (ported from reference SusChunkFinder)
   // Scans sections below Y=32 — typical dungeon/structure spawn range
   // -------------------------------------------------------------------------

   private void detectSpawnersAndVaults(WorldChunk chunk, ChunkScore result) {
      ChunkSection[] sections = chunk.getSectionArray();
      int bottomY = chunk.getBottomY();
      int baseX = chunk.getPos().getStartX();
      int baseZ = chunk.getPos().getStartZ();

      for (int i = 0; i < sections.length; ++i) {
         int sectionY = bottomY + i * 16;
         // Only scan below Y=32 — above that spawners are too common/natural
         if (sectionY > 32) break;

         ChunkSection section = sections[i];
         if (section == null || section.isEmpty()) continue;
         if (!section.getBlockStateContainer().hasAny(SusChunkScanner::isSpawnerOrVault)) continue;

         for (int x = 0; x < 16; ++x) {
            for (int y = 0; y < 16; ++y) {
               for (int z = 0; z < 16; ++z) {
                  BlockState state = section.getBlockState(x, y, z);
                  if (isSpawnerOrVault(state)) {
                     // Synthesise a BlockPos for scoring centroid
                     BlockPos pos = new BlockPos(baseX + x, sectionY + y, baseZ + z);
                     result.add(SignalType.SPAWNER, pos);
                     if (DEBUG_LOG) N0Client.LOGGER.info("[sus] SPAWNER/VAULT @{}", pos);
                  }
               }
            }
         }
      }
   }

   // -------------------------------------------------------------------------
   // Portal block detection (ported from reference SusChunkFinder)
   // Nether portals deep underground (<Y=0) are a very strong base indicator.
   // End portals anywhere are suspicious.
   // We track these separately for flash rendering and as a score signal.
   // -------------------------------------------------------------------------

   private void detectPortalBlocks(WorldChunk chunk, ChunkScore result) {
      ChunkSection[] sections = chunk.getSectionArray();
      int bottomY = chunk.getBottomY();
      int baseX = chunk.getPos().getStartX();
      int baseZ = chunk.getPos().getStartZ();
      int portalCount = 0;

      for (int i = 0; i < sections.length; ++i) {
         int sectionY = bottomY + i * 16;
         // End portals can be anywhere; nether portals we only care about underground
         ChunkSection section = sections[i];
         if (section == null || section.isEmpty()) continue;
         if (!section.getBlockStateContainer().hasAny(SusChunkScanner::isPortalBlock)) continue;

         // Limit Y check for nether portals: only flag if below Y=0 (underground)
         int maxYInSection = (sectionY < 0) ? Math.min(15, -sectionY - 1) : 15;

         for (int x = 0; x < 16; ++x) {
            for (int z = 0; z < 16; ++z) {
               for (int y = 0; y <= maxYInSection; ++y) {
                  BlockState state = section.getBlockState(x, y, z);
                  if (isPortalBlock(state)) {
                     ++portalCount;
                     if (portalCount >= PORTAL_BLOCK_THRESHOLD) {
                        BlockPos pos = new BlockPos(baseX + x, sectionY + y, baseZ + z);
                        result.add(SignalType.PORTAL, pos);
                        result.hasPortal = true;
                        if (DEBUG_LOG) N0Client.LOGGER.info("[sus] PORTAL @{}", pos);
                        // Don't need to count every block once we've flagged it
                        return;
                     }
                  }
               }
            }
         }
      }
   }

   // -------------------------------------------------------------------------
   // Rebuild — called every 10 ticks after scanning
   // -------------------------------------------------------------------------

   private void rebuild(MinecraftClient mc) {
      this.scores.keySet().removeIf(
            (key) -> mc.world.getChunkManager().getWorldChunk(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key), false) == null);

      int threshold = this.threshold();
      Map<Long, FlagAggregate> aggregates = new HashMap();

      // Collect portal chunks as a side channel
      Set<Long> newPortalChunks = new HashSet();

      for (ChunkScore score : this.scores.values()) {
         if (score.hasPortal) {
            newPortalChunks.add(score.chunkKey);
         }
         if (score.score >= (double) threshold) {
            FlagAggregate agg = (FlagAggregate) aggregates.computeIfAbsent(score.chunkKey, FlagAggregate::new);
            agg.score = Math.max(agg.score, score.score);
            agg.hitWeight += score.hitWeight;
            agg.hitX += score.hitX;
            agg.hitZ += score.hitZ;
         }
      }

      // Update portal set and flash timer
      if (!newPortalChunks.isEmpty() && this.portalChunks.isEmpty()) {
         this.portalFlashStartTime = System.currentTimeMillis();
      } else if (newPortalChunks.isEmpty()) {
         this.portalFlashStartTime = 0L;
      }
      this.portalChunks = Collections.unmodifiableSet(newPortalChunks);

      for (Geode geode : this.clusterGeodes()) {
         if (!(geode.score() < (double) threshold)) {
            for (long chunkKey : geode.chunks()) {
               FlagAggregate agg = (FlagAggregate) aggregates.computeIfAbsent(chunkKey, FlagAggregate::new);
               agg.score = Math.max(agg.score, geode.score());
            }
            double weight = SignalType.AMETHYST.weight;
            for (BlockPos cell : geode.cells()) {
               FlagAggregate agg = (FlagAggregate) aggregates.get(ChunkPos.toLong(cell.getX() >> 4, cell.getZ() >> 4));
               if (agg != null) {
                  agg.hitWeight += weight;
                  agg.hitX += ((double) cell.getX() + 0.5) * weight;
                  agg.hitZ += ((double) cell.getZ() + 0.5) * weight;
               }
            }
            if (DEBUG_LOG)
               N0Client.LOGGER.info("[sus] GEODE {} cells / {} chunks, score {} -> FLAG", geode.cells().size(), geode.chunks().size(), geode.score());
         }
      }

      List<Flag> flagged = new ArrayList();
      for (FlagAggregate agg : aggregates.values()) {
         flagged.add(new Flag(agg.chunkKey, agg.score));
      }
      this.flags = List.copyOf(flagged);
      this.zones = this.buildZones(flagged, aggregates);
      this.fireAlerts(mc);
   }

   private List<Geode> clusterGeodes() {
      List<BlockPos> cells = new ArrayList();
      for (ChunkScore score : this.scores.values()) {
         cells.addAll(score.amethystCells);
      }
      int n = cells.size();
      if (n == 0) return List.of();

      int[] parent = new int[n];
      for (int i = 0; i < n; parent[i] = i++) { }

      for (int i = 0; i < n; ++i) {
         BlockPos a = (BlockPos) cells.get(i);
         for (int j = i + 1; j < n; ++j) {
            BlockPos b = (BlockPos) cells.get(j);
            int chebyshev = Math.max(Math.abs(a.getX() - b.getX()),
                  Math.max(Math.abs(a.getY() - b.getY()), Math.abs(a.getZ() - b.getZ())));
            if (chebyshev <= GEODE_LINK_DISTANCE) {
               parent[find(parent, i)] = find(parent, j);
            }
         }
      }

      Map<Integer, List<BlockPos>> groups = new HashMap();
      for (int i = 0; i < n; ++i) {
         ((List) groups.computeIfAbsent(find(parent, i), (k) -> new ArrayList())).add((BlockPos) cells.get(i));
      }

      List<Geode> geodes = new ArrayList();
      for (List<BlockPos> group : groups.values()) {
         Set<Long> chunks = new HashSet();
         double sx = 0, sz = 0;
         for (BlockPos c : group) {
            chunks.add(ChunkPos.toLong(c.getX() >> 4, c.getZ() >> 4));
            sx += (double) c.getX() + 0.5;
            sz += (double) c.getZ() + 0.5;
         }
         double score = SignalType.AMETHYST.weight * (double) Math.min(group.size(), SignalType.AMETHYST.cap);
         geodes.add(new Geode(List.copyOf(group), Set.copyOf(chunks), score, sx / group.size(), sz / group.size()));
      }
      return geodes;
   }

   private static int find(int[] parent, int i) {
      while (parent[i] != i) {
         parent[i] = parent[parent[i]];
         i = parent[i];
      }
      return i;
   }

   private List<Zone> buildZones(List<Flag> flagged, Map<Long, FlagAggregate> aggregates) {
      int radius = Math.max(1, this.module.mergeRadius.getInt());
      Map<Long, Flag> byKey = new HashMap();
      for (Flag flag : flagged) {
         byKey.put(flag.chunkKey(), flag);
      }
      List<Zone> built = new ArrayList();
      Set<Long> visited = new HashSet();

      for (Flag seed : flagged) {
         if (visited.add(seed.chunkKey())) {
            List<Flag> group = new ArrayList();
            Deque<Flag> frontier = new ArrayDeque(List.of(seed));
            while (!frontier.isEmpty()) {
               Flag current = (Flag) frontier.poll();
               group.add(current);
               int cx = ChunkPos.getPackedX(current.chunkKey());
               int cz = ChunkPos.getPackedZ(current.chunkKey());
               for (int dx = -radius; dx <= radius; ++dx) {
                  for (int dz = -radius; dz <= radius; ++dz) {
                     if (dx != 0 || dz != 0) {
                        Flag neighbour = (Flag) byKey.get(ChunkPos.toLong(cx + dx, cz + dz));
                        if (neighbour != null && visited.add(neighbour.chunkKey())) {
                           frontier.add(neighbour);
                        }
                     }
                  }
               }
            }
            built.add(this.makeZone(group, aggregates));
         }
      }
      built.sort(Comparator.comparingDouble(Zone::totalScore).reversed());
      return built;
   }

   private Zone makeZone(List<Flag> group, Map<Long, FlagAggregate> aggregates) {
      Set<Long> members = new HashSet();
      double totalScore = 0, maxScore = 0, hitWeight = 0, hitX = 0, hitZ = 0, chunkX = 0, chunkZ = 0;
      for (Flag flag : group) {
         members.add(flag.chunkKey());
         totalScore += flag.score();
         maxScore = Math.max(maxScore, flag.score());
         FlagAggregate agg = (FlagAggregate) aggregates.get(flag.chunkKey());
         if (agg != null && agg.hitWeight > 0) {
            hitWeight += agg.hitWeight;
            hitX += agg.hitX;
            hitZ += agg.hitZ;
         }
         chunkX += (double) (ChunkPos.getPackedX(flag.chunkKey()) * 16 + 8) * flag.score();
         chunkZ += (double) (ChunkPos.getPackedZ(flag.chunkKey()) * 16 + 8) * flag.score();
      }
      double cx = hitWeight > 0 ? hitX / hitWeight : chunkX / totalScore;
      double cz = hitWeight > 0 ? hitZ / hitWeight : chunkZ / totalScore;
      return new Zone(Set.copyOf(members), cx, cz, totalScore, maxScore);
   }

   private void fireAlerts(MinecraftClient mc) {
      for (Zone zone : this.zones) {
         boolean isNew = true;
         for (long member : zone.members()) {
            if (this.alertedChunks.contains(member)) {
               isNew = false;
               break;
            }
         }
         if (!isNew) {
            this.alertedChunks.addAll(zone.members());
         } else {
            this.alertedChunks.addAll(zone.members());
            if (!this.module.notifications.is("Off")) {
               int bx = (int) Math.round(zone.centroidX());
               int bz = (int) Math.round(zone.centroidZ());
               int dist = (int) Math.hypot((double) bx - mc.player.getX(), (double) bz - mc.player.getZ());
               String message = "Sus zone · " + dist + "m · " + bx + ", " + bz;
               if (this.module.notifications.is("Toast") && N0Client.notifications() != null) {
                  N0Client.notifications().pushInfo(message);
                  UiSounds.notification(true);
               } else if (this.module.notifications.is("Chat")) {
                  mc.player.sendMessage(Text.literal("\u00a7d[N0] \u00a7f" + message), false);
               }
            }
         }
      }
   }

   // -------------------------------------------------------------------------
   // Signal type enum — extended with SPAWNER and PORTAL
   // -------------------------------------------------------------------------

   public static enum SignalType {
      AMETHYST(6.0, 16),
      KELP(2.0, 6),
      BAMBOO(2.0, 6),
      BERRIES(2.0, 5),
      VINES(2.0, 6),
      DRIPSTONE(2.0, 5),
      /** Monster spawner or vault block — very strong base indicator */
      SPAWNER(8.0, 8),
      /** Nether/end portal blocks deep underground */
      PORTAL(5.0, 4);

      public final double weight;
      public final int cap;

      private SignalType(double weight, int cap) {
         this.weight = weight;
         this.cap = cap;
      }
   }

   // -------------------------------------------------------------------------
   // Data types
   // -------------------------------------------------------------------------

   public static final class ChunkScore {
      public final long chunkKey;
      public final EnumMap<SignalType, Integer> hits = new EnumMap(SignalType.class);
      public final List<BlockPos> amethystCells = new ArrayList();
      public double score;
      /** Set to true if a portal block cluster was found in this chunk. */
      public boolean hasPortal;
      double hitWeight;
      double hitX;
      double hitZ;

      ChunkScore(long chunkKey) {
         this.chunkKey = chunkKey;
      }

      void add(SignalType type, BlockPos pos) {
         this.hits.merge(type, 1, Integer::sum);
         this.hitWeight += type.weight;
         this.hitX += ((double) pos.getX() + 0.5) * type.weight;
         this.hitZ += ((double) pos.getZ() + 0.5) * type.weight;
      }

      void computeScore() {
         double total = 0;
         for (Map.Entry<SignalType, Integer> entry : this.hits.entrySet()) {
            total += ((SignalType) entry.getKey()).weight
                  * (double) Math.min((Integer) entry.getValue(), ((SignalType) entry.getKey()).cap);
         }
         this.score = total;
      }
   }

   public static record Geode(List<BlockPos> cells, Set<Long> chunks, double score, double centroidX, double centroidZ) { }

   public static record Flag(long chunkKey, double score) { }

   public static record Zone(Set<Long> members, double centroidX, double centroidZ, double totalScore, double maxScore) { }

   private static final class FlagAggregate {
      final long chunkKey;
      double score;
      double hitWeight;
      double hitX;
      double hitZ;

      FlagAggregate(long chunkKey) {
         this.chunkKey = chunkKey;
      }
   }
}
