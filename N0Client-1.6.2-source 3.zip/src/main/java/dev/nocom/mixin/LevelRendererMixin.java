package dev.nocom.mixin;

import dev.nocom.N0Client;
import dev.nocom.module.ModuleManager;
import dev.nocom.render.AccessoryRenderer;
import dev.nocom.render.BlockEntityEspRenderer;
import dev.nocom.render.BlockEspRenderer;
import dev.nocom.render.BlockOutlineRenderer;
import dev.nocom.render.ChunkFinderRenderer;
import dev.nocom.render.EntityEspRenderer;
import dev.nocom.render.HitParticleRenderer;
import dev.nocom.render.HoleEspRenderer;
import dev.nocom.render.JumpCircleRenderer;
import dev.nocom.render.MiscBlockEspRenderer;
import dev.nocom.render.StorageEspRenderer;
import dev.nocom.render.SusChunkRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.state.OutlineRenderState;
import net.minecraft.client.render.state.WorldRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldRenderer.class})
public class LevelRendererMixin {
   @Inject(
      method = {"renderTargetBlockOutline(Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/util/math/MatrixStack;ZLnet/minecraft/client/render/state/WorldRenderState;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void n0client$customBlockOutline(VertexConsumerProvider.Immediate bufferSource, MatrixStack poseStack, boolean translucentPass, WorldRenderState levelRenderState, CallbackInfo ci) {
      ModuleManager modules = N0Client.modules();
      if (modules != null) {
         if (translucentPass && modules.susChunkFinder.isEnabled()) {
            SusChunkRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.susChunkFinder);
         }

         if (translucentPass && modules.chunkFinder != null && modules.chunkFinder.isEnabled()) {
            ChunkFinderRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.chunkFinder);
         }

         if (translucentPass && modules.storageEsp != null && modules.storageEsp.isEnabled()) {
            StorageEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.storageEsp);
         }

         if (translucentPass && modules.blockEsp != null && modules.blockEsp.isEnabled()) {
            BlockEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.blockEsp);
         }

         if (translucentPass && modules.blockEntityEsp != null && modules.blockEntityEsp.isEnabled()) {
            BlockEntityEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.blockEntityEsp);
         }

         if (translucentPass && modules.spawnerNametags != null && modules.spawnerNametags.isEnabled()) {
            MiscBlockEspRenderer.renderSpawners(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.spawnerNametags);
         }

         if (translucentPass && modules.debugHoleEsp != null && modules.debugHoleEsp.isEnabled()) {
            HoleEspRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.debugHoleEsp);
         }

         if (translucentPass && modules.playerEsp != null && modules.playerEsp.isEnabled()) {
            EntityEspRenderer.renderPlayers(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.playerEsp);
         }

         if (translucentPass && modules.mobEsp != null && modules.mobEsp.isEnabled()) {
            EntityEspRenderer.renderMobs(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.mobEsp);
         }

         if (translucentPass && modules.jumpCircles != null && modules.jumpCircles.isEnabled()) {
            JumpCircleRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.jumpCircles);
         }

         if (translucentPass && modules.hitParticles != null && modules.hitParticles.isEnabled()) {
            HitParticleRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.hitParticles);
         }

         if (translucentPass && modules.customAccessories != null && modules.customAccessories.isEnabled()) {
            AccessoryRenderer.render(bufferSource, poseStack, levelRenderState.cameraRenderState.pos, modules.customAccessories);
         }

         if (modules.freecam != null && modules.freecam.isActive()) {
            ci.cancel();
         } else if (modules.blockOutline.isEnabled()) {
            ci.cancel();
            OutlineRenderState state = levelRenderState.outlineRenderState;
            if (state != null && state.isTranslucent() == translucentPass) {
               BlockOutlineRenderer.render(bufferSource, poseStack, state, levelRenderState.cameraRenderState.pos, modules.blockOutline);
            }
         }
      }
   }
}
