package dev.nocom.gui.widget;

import dev.nocom.render.anim.Animation;
import dev.nocom.render.nanovg.NVGRenderer;
import dev.nocom.settings.SliderSetting;
import dev.nocom.theme.Theme;
import dev.nocom.theme.ThemeManager;
import dev.nocom.util.Colors;
import dev.nocom.util.UiSounds;

public class SliderWidget extends SettingWidget {
   public static final float HEIGHT = 27.0F;
   private static final float BAR_HEIGHT = 5.0F;
   private static final float KNOB_RADIUS = 5.0F;
   private final SliderSetting setting;
   private final Animation fill = new Animation(90.0F, 0.0F);
   private boolean dragging;

   public SliderWidget(ThemeManager themes, SliderSetting setting) {
      super(themes, setting);
      this.setting = setting;
      this.fill.snapTo((float)setting.getNormalized());
   }

   public float height(NVGRenderer vg) {
      return 27.0F;
   }

   public void render(NVGRenderer vg, float mx, float my) {
      Theme theme = this.theme();
      float textY = this.y + 8.0F;
      vg.text(this.setting.getName(), this.x, textY, 12.5F, theme.textMuted());
      String value = this.setting.formatValue();
      vg.text(value, this.x + this.width - vg.textWidth(value, 12.5F), textY, 12.5F, theme.textPrimary());
      float barY = this.y + 27.0F - 5.0F - 5.0F;
      this.fill.setTarget((float)this.setting.getNormalized());
      float t = Math.clamp(this.fill.value(), 0.0F, 1.0F);
      vg.rect(this.x, barY, this.width, 5.0F, 2.5F, Colors.withAlpha(-16777216, 0.45F));
      float fillW = Math.max(5.0F, t * this.width);
      vg.rectGradient(this.x, barY, fillW, 5.0F, 2.5F, theme.accent(), theme.accentBright(), false);
      float knobX = this.x + t * (this.width - 5.0F) + 2.5F;
      if (this.dragging) {
         vg.circleGlow(knobX, barY + 2.5F, 5.0F, 5.0F, theme.accentHover());
      }

      vg.circle(knobX, barY + 2.5F, 5.0F, -1);
   }

   public boolean mouseClicked(float mx, float my, int button) {
      if (button == 0 && this.contains(mx, my) && !(my < this.y + 10.0F)) {
         this.dragging = true;
         this.applyMouse(mx);
         return true;
      } else {
         return false;
      }
   }

   public void mouseDragged(float mx, float my) {
      if (this.dragging) {
         this.applyMouse(mx);
      }

   }

   public void mouseReleased() {
      this.dragging = false;
   }

   private void applyMouse(float mx) {
      double before = this.setting.getNormalized();
      this.setting.setNormalized((double)((mx - this.x) / this.width));
      if (this.setting.getNormalized() != before) {
         UiSounds.sliderTick((float)this.setting.getNormalized());
      }

   }
}
