# N0Client — Fabric 1.21.11

NanoVG ClickGUI client built for no-rules anarchy play.  
Based on N0Client v1.6.2 source, rebranded and extended.

## Build
```
./gradlew build
```
Output: `build/libs/n0client-1.6.2.jar`

## Requirements
- Java 21+
- Fabric Loader ≥ 0.19.0
- Fabric API (any for 1.21.11)
- Minecraft 1.21.11

## ClickGUI
Default keybind: **Right Shift**  
Panels are draggable; left-click a module to toggle, right-click to expand settings.

## SusChunkFinder — what's new vs N0Client
The existing amethyst-light + growth scanner has been extended with two new signal types:

| Signal | Weight | Description |
|---|---|---|
| **Spawners & Vaults** | 8.0 | Monster spawner / vault blocks below Y=32 — very strong base indicator |
| **Portals** | 5.0 | Nether/End portal blocks underground — triggers a white flash overlay |

Portal chunks are rendered as a separate **white pulsing overlay** (400 ms cycle,  
150 ms bright) on top of the normal sus-chunk quads, making active bases  
with portals immediately visible.

Toggle each signal type independently in the SusChunkFinder settings panel.

## Modules (existing)
Combat: AutoTotem, AutoCrystal, AnchorMacro, DoubleAnchor, AimAssist, MaceBomber,  
        MaceSwap, ShieldBreaker, Triggerbot, HoverTotem, AutoInventoryTotem,  
        ElytraSwap, FastUse, AutoClicker

Misc: NameProtect, SkinProtect, NameTags, FakePay, FakeStats, FakeRoles,  
      AutoTpa, AutoWalk, CoordSnapper, ChatMacro, StaffList, GambleRigger,  
      ArmorTrimHider, SpawnerProtect, WeatherNotifier, FreeLook, Freecam,  
      RegionMap, CustomAccessories

Render: SusChunkFinder, ChunkFinder, BlockEntityESP, BlockESP, PlayerESP,  
        MobESP, StorageESP, DebugHoleESP, SpawnerNametags, JumpCircles,  
        HitParticles, MotionBlur

Visuals: CustomBlockOutline, CustomCrosshair, CustomFOV, CustomGlint, Zoom,  
         SwingSpeed, Fullbright, FreeLook
